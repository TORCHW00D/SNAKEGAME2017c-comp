#include <iostream>
#include "SnakeGame.h"

using namespace std;

int main()
{
	bool game = true;
	int userChoice;
	while (game == true) {
		cout << "Welcome to snake! \nPress 1 to play. \nPress 2 for Credits. \n";
		cin >> userChoice;
		if (userChoice == 1) {
			FlyGame game;
			game.ConstructConsole(30, 30, 24, 24);
			game.Start();

		}
		else if (userChoice == 2) {
			cout << "Credits: \n Made by Thomas Wilson 11-05-19 \n";

		}
		else {

			exit(0);
		}
	}

	return 0;
}
