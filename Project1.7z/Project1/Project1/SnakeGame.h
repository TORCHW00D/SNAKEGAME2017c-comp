#pragma once
#include "olcConsoleGameEngineOOP.h"
#include <vector>

class FlyGame : public olcConsoleGameEngineOOP {

public:
	// A new type of data collection, the fly
	FlyGame();
	~FlyGame();
	void RenderWorld();
	struct Fly
	{
		int direction;
		float x;
		float y;
		float speedSecond = 15;
		int colour;
		wchar_t symbol;
		int LastX = 0;
		int LastY = 0;
		int BodySegments;

	};
	struct body
	{
		std::vector<int> x;
		std::vector<int> y;

		wchar_t symbol = 0x2666;
	};
	struct FrootLoop
	{
		int x;
		int y;
		int colour;
		wchar_t symbol;
	};

protected:
	// private variables can feel bad at first, like using globals
	// Remember though, we're encapsulating them. Don't go ham though.
	// Create an instance of a Fly for our blue fly
	int _score;


	// FLY SETUP
	const int START_X = 5;
	int FLY_COLOUR = BG_DARK_GREEN | FG_WHITE;
	const int GROUND_COLOUR = BG_DARK_BLUE | FG_DARK_GREEN;
	const int BORDER_COLOUR = BG_DARK_GREEN | FG_WHITE;
	const int SCORE_COLOUR = BG_DARK_GREEN | FG_WHITE;
	const int ORANGEFROOT = BG_DARK_GREEN | FG_YELLOW;
	const int BLUEFROOT = BG_DARK_GREEN | FG_DARK_BLUE;
	//FROOT ORANGE SETUP


	Fly _blueFly;
	FrootLoop yellow;
	FrootLoop blue;
	body _tail;
	// Inherited via olcConsoleGameEngineOOP
	void FlyMoving(int direction, float fElapsedTime);
	void BodyMoving();
	virtual bool OnUserCreate() override;
	virtual bool OnUserUpdate(float fElapsedTime) override;
};